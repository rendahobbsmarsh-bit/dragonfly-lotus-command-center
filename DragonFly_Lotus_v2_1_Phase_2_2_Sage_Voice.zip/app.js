const STORAGE_KEYS = Object.freeze({
  core: "dragonfly-lotus-v1",
  health: "dragonflyLotusHealthDashboard",
  flight: "dragonflyLotusFlightOperations",
  countdowns: "dragonflyLotusCountdowns",
  bliss: "dragonflyLotusBliss"
});

const KEY = STORAGE_KEYS.core;
const HEALTH_STORAGE_KEY = STORAGE_KEYS.health;
const FLIGHT_OPERATIONS_KEY = STORAGE_KEYS.flight;
const COUNTDOWN_STORAGE_KEY = STORAGE_KEYS.countdowns;
const BLISS_STORAGE_KEY = STORAGE_KEYS.bliss;
function readStorage(key, fallback) {
  try {
    return JSON.parse(localStorage.getItem(key) || "null") ?? fallback;
  } catch (error) {
    console.warn(`Could not read ${key}.`, error);
    return fallback;
  }
}

function makeId() {
  return typeof crypto !== "undefined" && crypto.randomUUID
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random()}`;
}

const defaults = {
  mode: "home",
  mission: "",
  reportTime: "",
  leaveTime: "",
  pairing: "2 days",
  current: "",
  next: "",
  later: "",
  water: 0,
  protein: 0,
  exercise: false,
  workout: "",
  weight: "",
  photo: "",
  appointmentPurpose: "",
  appointmentQuestions: "",
  appointmentNotes: "",
  followUpDate: "",
  appointmentNextStep: "",
  tasks: ["Stretch", "Take one photo", "Read 20 minutes", "10 minutes of sunshine"]
    .map(text => ({ id: makeId(), text, done: false })),
  bills: []
};

let state = {
  ...defaults,
  ...readStorage(KEY, {})
};

const $ = selector => document.querySelector(selector);
const $$ = selector => [...document.querySelectorAll(selector)];

function save() {
  localStorage.setItem(KEY, JSON.stringify(state));
}

function numberOrZero(value) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.max(0, number) : 0;
}

function getSavedHealth() {
  const saved = readStorage(HEALTH_STORAGE_KEY, {});
  return {
    waterValue: numberOrZero(saved.waterValue ?? saved.water ?? state.water),
    proteinValue: numberOrZero(saved.proteinValue ?? saved.protein ?? state.protein),
    weightValue: saved.weightValue ?? state.weight ?? "",
    sleepValue: saved.sleepValue ?? "",
    exerciseComplete: Boolean(
      saved.exerciseComplete ?? saved.exercise ?? state.exercise
    ),
    healthNotes: saved.healthNotes ?? ""
  };
}

function getHealthData() {
  const saved = getSavedHealth();
  const live = (id, fallback) => {
    const field = document.getElementById(id);
    if (!field) return fallback;
    return field.type === "checkbox" ? field.checked : field.value;
  };

  return {
    waterValue: numberOrZero(live("waterValue", saved.waterValue)),
    proteinValue: numberOrZero(live("proteinValue", saved.proteinValue)),
    weightValue: live("weightValue", saved.weightValue) ?? "",
    sleepValue: live("sleepValue", saved.sleepValue) ?? "",
    exerciseComplete: Boolean(
      live("exerciseComplete", saved.exerciseComplete)
    ),
    healthNotes: live("healthNotes", saved.healthNotes) ?? ""
  };
}

function saveUnifiedHealth(health = getHealthData()) {
  const normalized = {
    waterValue: numberOrZero(health.waterValue),
    proteinValue: numberOrZero(health.proteinValue),
    weightValue: health.weightValue ?? "",
    sleepValue: health.sleepValue ?? "",
    exerciseComplete: Boolean(health.exerciseComplete),
    healthNotes: health.healthNotes ?? ""
  };

  localStorage.setItem(HEALTH_STORAGE_KEY, JSON.stringify(normalized));

  state.water = normalized.waterValue;
  state.protein = normalized.proteinValue;
  state.weight = normalized.weightValue;
  state.exercise = normalized.exerciseComplete;
  save();

  return normalized;
}

function refreshSharedViews() {
  if (typeof renderHealth === "function") renderHealth();
  if (typeof updateHealthProgress === "function") updateHealthProgress(false);
  if (typeof updateCaptainsBriefing === "function") updateCaptainsBriefing();
  if (typeof updateCaptainRecommendations === "function") {
    updateCaptainRecommendations();
  }
  if (typeof updateMorningIntelligence === "function") {
    updateMorningIntelligence();
  }
}

function clock(){
 const now=new Date();
 $("#time").textContent=now.toLocaleTimeString([],{
   hour:"numeric",minute:"2-digit"
 });
 $("#date").textContent=now.toLocaleDateString([],{
   weekday:"long",month:"long",day:"numeric",year:"numeric"
 });
 countdown(now);
}

function countdown(now=new Date()){
 if(!state.leaveTime){
   $("#countdown").textContent="Set leave-home time"; return;
 }
 const [h,m]=state.leaveTime.split(":").map(Number);
 const target=new Date(now);
 target.setHours(h,m,0,0);
 if(target<now) target.setDate(target.getDate()+1);
 const mins=Math.floor((target-now)/60000);
 $("#countdown").textContent=`${Math.floor(mins/60)}h ${mins%60}m`;
}

function bind(id, key, event = "input") {
  const el = $(id);
  if (!el) return;

  el.value = state[key] ?? "";
  el.addEventListener(event, e => {
    state[key] = e.target.value;
    save();

    if (key === "leaveTime") countdown();

    if (key === "weight") {
      const health = getHealthData();
      health.weightValue = e.target.value;
      saveUnifiedHealth(health);
      populateHealthFields(health);
    }

    if (typeof updateCaptainsBriefing === "function") {
      updateCaptainsBriefing();
    }
    if (typeof updateCaptainRecommendations === "function") {
      updateCaptainRecommendations();
    }
  });
}

const modeData={
 home:["HOME","Dragonfly Bliss",[
   "Laundry / linen / lawn rotation",
   "Home project or garden focus",
   "Meal prep and food bag reset"
 ]],
 flight:["FLIGHT","Ready for Departure",[
   "Crew badge, passport, chargers and camera",
   "Food bag and water ready",
   "Confirm report time, airport, van and hotel"
 ]],
 turbulence:["EASE","Turbulence Protocol",[
   "Choose one essential mission",
   "Hydrate, eat and take medication",
   "Everything else may move to later"
 ]]
};

function setMode(mode){
 state.mode=mode; save();
 $$(".mode").forEach(b=>b.classList.toggle("active",b.dataset.mode===mode));
 const [badge,title,notes]=modeData[mode];
 $("#modeBadge").textContent=badge;
 $("#modeTitle").textContent=title;
 $("#modeNotes").innerHTML=notes.map(n=>`<div>${n}</div>`).join("");
}

function renderTasks(){
 $("#tasks").innerHTML="";
 state.tasks.forEach(task=>{
   const li=document.createElement("li");
   li.className=task.done?"done":"";
   li.innerHTML=`<input type="checkbox" ${task.done?"checked":""}>
     <span></span><button type="button">✕</button>`;
   li.querySelector("span").textContent=task.text;
   li.querySelector("input").onchange=e=>{
     task.done=e.target.checked; save(); renderTasks();
   };
   li.querySelector("button").onclick=()=>{
     state.tasks=state.tasks.filter(t=>t.id!==task.id);
     save(); renderTasks();
   };
   $("#tasks").append(li);
 });
}

function renderHealth() {
  const health = getHealthData();

  const water = document.getElementById("water");
  const protein = document.getElementById("protein");
  const waterBar = document.getElementById("waterBar");
  const proteinBar = document.getElementById("proteinBar");
  const exercise = document.getElementById("exercise");

  if (water) water.textContent = health.waterValue;
  if (protein) protein.textContent = health.proteinValue;
  if (waterBar) waterBar.value = health.waterValue;
  if (proteinBar) proteinBar.value = health.proteinValue;
  if (exercise) exercise.checked = health.exerciseComplete;
}

function renderBills(){
 $("#bills").innerHTML="";
 [...state.bills].sort((a,b)=>a.date.localeCompare(b.date)).forEach(bill=>{
   const li=document.createElement("li");
   li.className=bill.paid?"done":"";
   const amount=bill.amount?` • $${Number(bill.amount).toFixed(2)}`:"";
   li.innerHTML=`<input type="checkbox" ${bill.paid?"checked":""}>
     <span></span><button type="button">✕</button>`;
   li.querySelector("span").textContent=
     `${bill.name} — ${bill.date}${amount}`;
   li.querySelector("input").onchange=e=>{
     bill.paid=e.target.checked; save(); renderBills();
   };
   li.querySelector("button").onclick=()=>{
     state.bills=state.bills.filter(b=>b.id!==bill.id);
     save(); renderBills();
   };
   $("#bills").append(li);
 });
}

bind("#mission","mission");
bind("#reportTime","reportTime","change");
bind("#leaveTime","leaveTime","change");
bind("#pairing","pairing","change");
bind("#current","current");
bind("#next","next");
bind("#later","later");
bind("#workout","workout");
bind("#weight","weight");
bind("#photo","photo");

$$(".mode").forEach(b=>b.onclick=()=>setMode(b.dataset.mode));

$("#taskForm").onsubmit=e=>{
 e.preventDefault();
 const input=$("#taskInput");
 if(!input.value.trim()) return;
 state.tasks.push({
   id:makeId(),text:input.value.trim(),done:false
 });
 input.value=""; save(); renderTasks();
};

$$("[data-water]").forEach(button => {
  button.onclick = () => {
    const health = getHealthData();
    health.waterValue = Math.max(
      0,
      health.waterValue + Number(button.dataset.water)
    );
    saveUnifiedHealth(health);
    populateHealthFields(health);
    refreshSharedViews();
  };
});

$$("[data-protein]").forEach(button => {
  button.onclick = () => {
    const health = getHealthData();
    health.proteinValue = Math.max(
      0,
      health.proteinValue + Number(button.dataset.protein)
    );
    saveUnifiedHealth(health);
    populateHealthFields(health);
    refreshSharedViews();
  };
});

if ($("#exercise")) {
  $("#exercise").onchange = event => {
    const health = getHealthData();
    health.exerciseComplete = event.target.checked;
    saveUnifiedHealth(health);
    populateHealthFields(health);
    refreshSharedViews();
  };
}

$("#billForm").onsubmit=e=>{
 e.preventDefault();
 const name=$("#billName"), amount=$("#billAmount"), date=$("#billDate");
 state.bills.push({
   id:crypto.randomUUID(),name:name.value.trim(),
   amount:amount.value,date:date.value,paid:false
 });
 e.target.reset(); save(); renderBills();
};


bind("#appointmentPurpose","appointmentPurpose");
bind("#appointmentQuestions","appointmentQuestions");
bind("#appointmentNotes","appointmentNotes");
bind("#followUpDate","followUpDate","change");
bind("#appointmentNextStep","appointmentNextStep");

setMode(state.mode);
renderTasks();
renderHealth();
renderBills();
clock();
setInterval(clock,1000);


// Flight Operations autosave
const flightOperationIds = [
  "opsFlightNumber",
  "opsRoute",
  "opsAircraft",
  "opsPosition",
  "opsLayover",
  "opsVanTime",
  "opsHotel",
  "opsCrewNotes"
];

function initializeFlightOperations() {
  let saved = {};

  try {
    saved = JSON.parse(
      localStorage.getItem(FLIGHT_OPERATIONS_KEY) || "{}"
    );
  } catch (error) {
    console.warn("Flight Operations could not be loaded.", error);
  }

  flightOperationIds.forEach(id => {
    const field = document.getElementById(id);
    if (!field) return;

    field.value = saved[id] || "";

    const save = () => {
      const current = {};

      flightOperationIds.forEach(fieldId => {
        const currentField = document.getElementById(fieldId);
        current[fieldId] = currentField ? currentField.value : "";
      });

      localStorage.setItem(
        FLIGHT_OPERATIONS_KEY,
        JSON.stringify(current)
      );
    };

    field.addEventListener("input", save);
    field.addEventListener("change", save);
  });
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initializeFlightOperations, { once: true });
} else {
  initializeFlightOperations();
}


// Health Dashboard — one shared source of truth
const healthIds = [
  "waterValue",
  "proteinValue",
  "weightValue",
  "sleepValue",
  "exerciseComplete",
  "healthNotes"
];

function populateHealthFields(health = getSavedHealth()) {
  healthIds.forEach(id => {
    const field = document.getElementById(id);
    if (!field) return;

    const value = health[id];

    if (field.type === "checkbox") {
      field.checked = Boolean(value);
    } else {
      field.value = value ?? "";
    }
  });

  const originalWeight = document.getElementById("weight");
  if (originalWeight && health.weightValue !== undefined) {
    originalWeight.value = health.weightValue ?? "";
  }

  const originalExercise = document.getElementById("exercise");
  if (originalExercise) {
    originalExercise.checked = Boolean(health.exerciseComplete);
  }
}

function updateHealthProgress(shouldRefreshDependents = true) {
  const health = getHealthData();

  const waterDisplay = document.getElementById("waterDisplay");
  const proteinDisplay = document.getElementById("proteinDisplay");
  const waterProgress = document.getElementById("waterProgress");
  const proteinProgress = document.getElementById("proteinProgress");
  const status = document.getElementById("healthStatus");

  if (waterDisplay) waterDisplay.textContent = health.waterValue;
  if (proteinDisplay) proteinDisplay.textContent = health.proteinValue;

  if (waterProgress) {
    waterProgress.style.width =
      `${Math.min(100, (health.waterValue / 128) * 100)}%`;
  }

  if (proteinProgress) {
    proteinProgress.style.width =
      `${Math.min(100, (health.proteinValue / 170) * 100)}%`;
  }

  if (status) {
    if (
      health.waterValue >= 128 &&
      health.proteinValue >= 170 &&
      health.exerciseComplete
    ) {
      status.textContent = "GOALS COMPLETE";
    } else if (
      health.waterValue > 0 ||
      health.proteinValue > 0 ||
      health.exerciseComplete
    ) {
      status.textContent = "IN PROGRESS";
    } else {
      status.textContent = "DAILY PROGRESS";
    }
  }

  if (shouldRefreshDependents) {
    renderHealth();
    updateCaptainsBriefing();
    updateCaptainRecommendations();
    if (typeof updateMorningIntelligence === "function") {
      updateMorningIntelligence();
    }
  }
}

function saveHealthDashboard() {
  const health = saveUnifiedHealth(getHealthData());
  populateHealthFields(health);
  updateHealthProgress();
}

function initializeHealthDashboard() {
  const saved = getSavedHealth();

  // Migrate whichever copy contains real information into both stores.
  const mainHasHealth =
    numberOrZero(state.water) > 0 ||
    numberOrZero(state.protein) > 0 ||
    Boolean(state.exercise) ||
    Boolean(state.weight);

  const savedHasHealth =
    saved.waterValue > 0 ||
    saved.proteinValue > 0 ||
    saved.exerciseComplete ||
    Boolean(saved.weightValue) ||
    Boolean(saved.sleepValue) ||
    Boolean(saved.healthNotes);

  const initial = savedHasHealth
    ? saved
    : {
        ...saved,
        waterValue: numberOrZero(state.water),
        proteinValue: numberOrZero(state.protein),
        weightValue: state.weight ?? "",
        exerciseComplete: Boolean(state.exercise)
      };

  saveUnifiedHealth(initial);
  populateHealthFields(initial);

  healthIds.forEach(id => {
    const field = document.getElementById(id);
    if (!field || field.dataset.healthBound === "true") return;

    field.dataset.healthBound = "true";
    field.addEventListener("input", saveHealthDashboard);
    field.addEventListener("change", saveHealthDashboard);
  });

  const originalWeight = document.getElementById("weight");
  if (originalWeight && originalWeight.dataset.healthBound !== "true") {
    originalWeight.dataset.healthBound = "true";
    originalWeight.addEventListener("input", event => {
      const health = getHealthData();
      health.weightValue = event.target.value;
      saveUnifiedHealth(health);
      populateHealthFields(health);
      refreshSharedViews();
    });
  }

  updateHealthProgress();
}

if (document.readyState === "loading") {
  document.addEventListener(
    "DOMContentLoaded",
    initializeHealthDashboard,
    { once: true }
  );
} else {
  initializeHealthDashboard();
}


// Countdown Center
function loadCountdowns() {
  try {
    const saved = JSON.parse(
      localStorage.getItem(COUNTDOWN_STORAGE_KEY) || "[]"
    );

    return Array.isArray(saved) ? saved : [];
  } catch (error) {
    console.warn("Countdowns could not be loaded.", error);
    return [];
  }
}

let countdownItems = loadCountdowns();

function saveCountdowns() {
  localStorage.setItem(
    COUNTDOWN_STORAGE_KEY,
    JSON.stringify(countdownItems)
  );
}

function localDateFromInput(dateValue) {
  const [year, month, day] = dateValue.split("-").map(Number);
  return new Date(year, month - 1, day);
}

function startOfToday() {
  const today = new Date();
  return new Date(
    today.getFullYear(),
    today.getMonth(),
    today.getDate()
  );
}

function calculateDaysRemaining(dateValue) {
  const target = localDateFromInput(dateValue);
  const today = startOfToday();
  return Math.round((target - today) / 86400000);
}

function formatCountdownDate(dateValue) {
  return localDateFromInput(dateValue).toLocaleDateString([], {
    weekday: "short",
    month: "short",
    day: "numeric",
    year: "numeric"
  });
}

function countdownLabel(days) {
  if (days === 0) {
    return {
      number: "TODAY",
      label: "ARRIVED"
    };
  }

  if (days === 1) {
    return {
      number: "1",
      label: "DAY"
    };
  }

  if (days > 1) {
    return {
      number: String(days),
      label: "DAYS"
    };
  }

  const elapsed = Math.abs(days);

  return {
    number: String(elapsed),
    label: elapsed === 1 ? "DAY AGO" : "DAYS AGO"
  };
}

function renderCountdowns() {
  const list = document.getElementById("countdownList");
  const empty = document.getElementById("countdownEmpty");
  const status = document.getElementById("countdownStatus");

  if (!list || !empty || !status) return;

  list.innerHTML = "";

  countdownItems.sort((a, b) => {
    return a.date.localeCompare(b.date);
  });

  const activeCount = countdownItems.filter(item => {
    return calculateDaysRemaining(item.date) >= 0;
  }).length;

  status.textContent =
    `${activeCount} ACTIVE`;

  empty.hidden = countdownItems.length > 0;

  countdownItems.forEach(item => {
    const days = calculateDaysRemaining(item.date);
    const display = countdownLabel(days);

    const card = document.createElement("article");
    card.className = "countdown-item";

    if (days === 0) {
      card.classList.add("is-today");
    }

    if (days < 0) {
      card.classList.add("is-past");
    }

    const main = document.createElement("div");
    main.className = "countdown-item-main";

    const name = document.createElement("h3");
    name.className = "countdown-item-name";
    name.textContent = item.name;

    const meta = document.createElement("div");
    meta.className = "countdown-item-meta";

    const date = document.createElement("span");
    date.textContent = formatCountdownDate(item.date);

    const category = document.createElement("span");
    category.className = "countdown-category";
    category.textContent = item.category;

    meta.append(date, category);
    main.append(name, meta);

    const daysBlock = document.createElement("div");
    daysBlock.className = "countdown-days";

    const number = document.createElement("strong");
    number.textContent = display.number;

    const label = document.createElement("span");
    label.textContent = display.label;

    daysBlock.append(number, label);

    const deleteButton = document.createElement("button");
    deleteButton.className = "countdown-delete";
    deleteButton.type = "button";
    deleteButton.setAttribute(
      "aria-label",
      `Delete ${item.name}`
    );
    deleteButton.textContent = "✕";

    deleteButton.addEventListener("click", () => {
      countdownItems = countdownItems.filter(
        countdown => countdown.id !== item.id
      );

      saveCountdowns();
      renderCountdowns();
    });

    card.append(main, daysBlock, deleteButton);
    list.append(card);
  });
}

function initializeCountdownCenter() {
  const form = document.getElementById("countdownForm");
  const nameField = document.getElementById("countdownName");
  const dateField = document.getElementById("countdownDate");
  const categoryField = document.getElementById("countdownCategory");

  if (!form || !nameField || !dateField || !categoryField) {
    return;
  }

  form.addEventListener("submit", event => {
    event.preventDefault();

    const name = nameField.value.trim();
    const date = dateField.value;
    const category = categoryField.value;

    if (!name || !date) return;

    countdownItems.push({
      id:
        typeof crypto !== "undefined" && crypto.randomUUID
          ? crypto.randomUUID()
          : `${Date.now()}-${Math.random()}`,
      name,
      date,
      category
    });

    saveCountdowns();
    renderCountdowns();

    form.reset();
    categoryField.value = "Personal";
    nameField.focus();
  });

  renderCountdowns();
}

if (document.readyState === "loading") {
  document.addEventListener(
    "DOMContentLoaded",
    initializeCountdownCenter,
    { once: true }
  );
} else {
  initializeCountdownCenter();
}


// Dragonfly Bliss autosave
const blissFieldIds = [
  "blissHome",
  "blissHomeDone",
  "blissGarden",
  "blissGardenDone",
  "blissPhotography",
  "blissPhotographyDone",
  "blissMealPrep",
  "blissMealPrepDone",
  "blissLaundry",
  "blissLaundryDone",
  "blissWorkout",
  "blissWorkoutDone",
  "blissNotes"
];

const blissCompletionIds = [
  "blissHomeDone",
  "blissGardenDone",
  "blissPhotographyDone",
  "blissMealPrepDone",
  "blissLaundryDone",
  "blissWorkoutDone"
];

function loadDragonflyBliss() {
  return readStorage(BLISS_STORAGE_KEY, {});
}

function updateDragonflyBlissStatus() {
  const status = document.getElementById("blissStatus");

  const completed = blissCompletionIds.filter(id => {
    return document.getElementById(id)?.checked;
  }).length;

  if (status) {
    status.textContent = `${completed} OF 6 COMPLETE`;
  }

  blissCompletionIds.forEach(id => {
    const checkbox = document.getElementById(id);
    const card = checkbox?.closest(".bliss-item");

    if (card) {
      card.classList.toggle(
        "is-complete",
        Boolean(checkbox.checked)
      );
    }
  });
}

function saveDragonflyBliss() {
  const saved = {};

  blissFieldIds.forEach(id => {
    const field = document.getElementById(id);

    if (!field) return;

    saved[id] =
      field.type === "checkbox"
        ? field.checked
        : field.value;
  });

  localStorage.setItem(
    BLISS_STORAGE_KEY,
    JSON.stringify(saved)
  );

  updateDragonflyBlissStatus();
}

function initializeDragonflyBliss() {
  const saved = loadDragonflyBliss();

  blissFieldIds.forEach(id => {
    const field = document.getElementById(id);

    if (!field) return;

    if (field.type === "checkbox") {
      field.checked = Boolean(saved[id]);
    } else {
      field.value = saved[id] || "";
    }

    field.addEventListener("input", saveDragonflyBliss);
    field.addEventListener("change", saveDragonflyBliss);
  });

  updateDragonflyBlissStatus();
}

if (document.readyState === "loading") {
  document.addEventListener(
    "DOMContentLoaded",
    initializeDragonflyBliss,
    { once: true }
  );
} else {
  initializeDragonflyBliss();
}


// Captain's Briefing
function readCaptainStorage(key, fallback) {
  try { return JSON.parse(localStorage.getItem(key) || "null") ?? fallback; }
  catch { return fallback; }
}

function setCaptainText(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

function captainTime(value) {
  if (!value) return "";
  const [h, m] = value.split(":").map(Number);
  const d = new Date();
  d.setHours(h, m, 0, 0);
  return d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
}

function updateCaptainsBriefing() {
  const state = readCaptainStorage("dragonfly-lotus-v1", {});
  const health = getHealthData();
  const flight = readCaptainStorage("dragonflyLotusFlightOperations", {});
  const countdowns = readCaptainStorage("dragonflyLotusCountdowns", []);
  const bliss = readCaptainStorage("dragonflyLotusBliss", {});

  const now = new Date();
  const greeting = now.getHours() < 12 ? "Good Morning" : now.getHours() < 17 ? "Good Afternoon" : "Good Evening";
  setCaptainText("captainGreeting", `${greeting}, Captain Ren`);
  setCaptainText("captainDate", now.toLocaleDateString([], { weekday:"long", month:"long", day:"numeric", year:"numeric" }));

  const mode = String(state.mode || "home").toUpperCase();
  setCaptainText("captainMode", `${mode} MODE`);
  setCaptainText("captainMission", (state.mission || "").trim() || "Set today's mission below.");

  const flightNumber = (flight.opsFlightNumber || "").trim();
  const route = (flight.opsRoute || "").trim();
  setCaptainText("captainFlight", [flightNumber, route].filter(Boolean).join(" • ") || "No flight entered");

  const times = [];
  if (state.leaveTime) times.push(`Leave ${captainTime(state.leaveTime)}`);
  if (state.reportTime) times.push(`Report ${captainTime(state.reportTime)}`);
  setCaptainText("captainTimes", times.join(" • ") || "Times not set");

  const water = Number(health.waterValue ?? state.water ?? 0) || 0;
  const protein = Number(health.proteinValue ?? state.protein ?? 0) || 0;
  const exercise = Boolean(health.exerciseComplete ?? state.exercise);
  setCaptainText("captainWater", `${water} / 128 oz`);
  setCaptainText("captainProtein", `${protein} / 170 g`);
  setCaptainText("captainExercise", exercise ? "Complete" : "Not complete");

  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const active = Array.isArray(countdowns) ? countdowns.map(item => {
    const date = new Date(`${item.date}T00:00:00`);
    return { ...item, days: Math.round((date - today) / 86400000) };
  }).filter(item => Number.isFinite(item.days) && item.days >= 0).sort((a,b) => a.days-b.days) : [];

  if (active[0]) {
    setCaptainText("captainCountdown", active[0].name || active[0].event || "Upcoming event");
    setCaptainText("captainCountdownDays", active[0].days === 0 ? "Today" : `${active[0].days} day${active[0].days === 1 ? "" : "s"} remaining`);
  } else {
    setCaptainText("captainCountdown", "No active countdown");
    setCaptainText("captainCountdownDays", "Add a date below");
  }

  const done = ["blissHomeDone","blissGardenDone","blissPhotographyDone","blissMealPrepDone","blissLaundryDone","blissWorkoutDone"]
    .filter(id => Boolean(bliss[id])).length;
  setCaptainText("captainBliss", `${done} of 6 complete`);
}

function initializeCaptainsBriefing() {
  updateCaptainsBriefing();
  document.addEventListener("input", () => setTimeout(updateCaptainsBriefing, 0));
  document.addEventListener("change", () => setTimeout(updateCaptainsBriefing, 0));
  setInterval(updateCaptainsBriefing, 60000);
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initializeCaptainsBriefing, { once:true });
} else {
  initializeCaptainsBriefing();
}


// Captain's Recommendations
function recommendationsReadStorage(key, fallback) {
  try {
    return JSON.parse(localStorage.getItem(key) || "null") ?? fallback;
  } catch {
    return fallback;
  }
}

function recommendationsNumber(...values) {
  for (const value of values) {
    const number = Number(value);
    if (Number.isFinite(number)) return number;
  }
  return 0;
}

function recommendationsDaysUntil(dateValue) {
  if (!dateValue) return null;

  const parts = String(dateValue).split("-").map(Number);
  if (parts.length !== 3 || parts.some(part => !Number.isFinite(part))) {
    return null;
  }

  const target = new Date(parts[0], parts[1] - 1, parts[2]);
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  return Math.round((target - today) / 86400000);
}

function recommendationCard(icon, title, detail, tone = "") {
  return `
    <article class="recommendation-item ${tone}">
      <span class="recommendation-icon">${icon}</span>
      <div>
        <strong>${title}</strong>
        <p>${detail}</p>
      </div>
    </article>
  `;
}

function updateCaptainRecommendations() {
  const list = document.getElementById("recommendationsList");
  const status = document.getElementById("recommendationsStatus");
  if (!list) return;

  const state = recommendationsReadStorage("dragonfly-lotus-v1", {});
  const health = getHealthData();
  const flight = recommendationsReadStorage("dragonflyLotusFlightOperations", {});
  const countdowns = recommendationsReadStorage("dragonflyLotusCountdowns", []);
  const bliss = recommendationsReadStorage("dragonflyLotusBliss", {});

  const recommendations = [];
  const mode = String(state.mode || "home").toLowerCase();

  const water = Math.max(
    0,
    recommendationsNumber(
      health.waterValue,
      health.water,
      state.water
    )
  );

  const protein = Math.max(
    0,
    recommendationsNumber(
      health.proteinValue,
      health.protein,
      state.protein
    )
  );

  const exercise = Boolean(
    health.exerciseComplete ??
    health.exercise ??
    state.exercise
  );

  if (water < 64) {
    recommendations.push({
      icon: "💧",
      title: "Bring water forward",
      detail: `You are at ${water} of 128 oz. Your next simple move is one full bottle or two airplane waters.`,
      tone: "priority"
    });
  } else if (water < 128) {
    recommendations.push({
      icon: "💧",
      title: "Water goal is within reach",
      detail: `${128 - water} oz remain. Keep a bottle visible and finish the next serving before changing tasks.`
    });
  }

  if (protein < 85) {
    recommendations.push({
      icon: "🥤",
      title: "Anchor the next meal with protein",
      detail: `You are at ${protein} of 170 g. Choose one dependable protein source before adding extras.`,
      tone: "priority"
    });
  } else if (protein < 170) {
    recommendations.push({
      icon: "🥤",
      title: "Protect your protein momentum",
      detail: `${170 - protein} g remain. Plan one protein-forward meal or Devotion serving.`
    });
  }

  if (!exercise) {
    recommendations.push({
      icon: "💪",
      title: mode === "turbulence" ? "Choose gentle movement" : "Put movement on the flight path",
      detail: mode === "turbulence"
        ? "A short stretch, mobility session or recovery walk is enough today."
        : "A focused workout, walk or mobility session will complete this instrument."
    });
  }

  const activeCountdowns = Array.isArray(countdowns)
    ? countdowns
        .map(item => ({
          ...item,
          days: recommendationsDaysUntil(item.date)
        }))
        .filter(item => item.days !== null && item.days >= 0)
        .sort((a, b) => a.days - b.days)
    : [];

  const nextCountdown = activeCountdowns[0];
  if (nextCountdown && nextCountdown.days <= 14) {
    const name = nextCountdown.name || nextCountdown.event || "Your next event";
    recommendations.push({
      icon: "📅",
      title: nextCountdown.days === 0 ? `${name} is today` : `${name} is approaching`,
      detail: nextCountdown.days === 0
        ? "Review the final details and protect enough transition time."
        : `${nextCountdown.days} day${nextCountdown.days === 1 ? "" : "s"} remain. Choose one preparation step for today.`,
      tone: nextCountdown.days <= 3 ? "priority" : ""
    });
  }

  const blissAreas = [
    ["blissHomeDone", "Home"],
    ["blissGardenDone", "Garden"],
    ["blissPhotographyDone", "Photography"],
    ["blissMealPrepDone", "Meal prep"],
    ["blissLaundryDone", "Laundry"],
    ["blissWorkoutDone", "Workout"]
  ];

  const incompleteBliss = blissAreas.filter(([id]) => !Boolean(bliss[id]));
  const completedBliss = blissAreas.length - incompleteBliss.length;

  if (mode === "home" && incompleteBliss.length > 0) {
    const focus = incompleteBliss[0][1];
    recommendations.push({
      icon: "🌿",
      title: `A gentle ${focus.toLowerCase()} win fits Home Mode`,
      detail: `${completedBliss} of 6 Dragonfly Bliss areas are complete. One small ${focus.toLowerCase()} action is enough.`
    });
  }

  const hasFlight =
    Boolean((flight.opsFlightNumber || "").trim()) ||
    Boolean((flight.opsRoute || "").trim());

  if (mode === "flight" && !hasFlight) {
    recommendations.push({
      icon: "✈️",
      title: "Complete the flight picture",
      detail: "Add the flight number or route so the briefing can carry your operational details.",
      tone: "priority"
    });
  }

  if (!(state.mission || "").trim()) {
    recommendations.push({
      icon: "🎯",
      title: "Name one mission",
      detail: "Choose the single outcome that would make today feel intentionally flown."
    });
  }

  const visible = recommendations.slice(0, 4);

  if (visible.length === 0) {
    visible.push({
      icon: "✓",
      title: "All primary systems are steady",
      detail: "Your core goals are in good shape. Protect your pace and enjoy the day you built.",
      tone: "success"
    });
  }

  list.innerHTML = visible
    .map(item => recommendationCard(item.icon, item.title, item.detail, item.tone))
    .join("");

  if (status) {
    const priorityCount = visible.filter(item => item.tone === "priority").length;
    status.textContent = priorityCount
      ? `${priorityCount} PRIORITY ${priorityCount === 1 ? "ITEM" : "ITEMS"}`
      : "STEADY GUIDANCE";
  }
}

function initializeCaptainRecommendations() {
  updateCaptainRecommendations();

  document.addEventListener("input", () => {
    setTimeout(updateCaptainRecommendations, 0);
  });

  document.addEventListener("change", () => {
    setTimeout(updateCaptainRecommendations, 0);
  });

  window.addEventListener("storage", updateCaptainRecommendations);
  setInterval(updateCaptainRecommendations, 60000);
}

if (document.readyState === "loading") {
  document.addEventListener(
    "DOMContentLoaded",
    initializeCaptainRecommendations,
    { once: true }
  );
} else {
  initializeCaptainRecommendations();
}


// Synchronize open tabs/windows on the same device.
window.addEventListener("storage", event => {
  if (
    event.key === KEY ||
    event.key === HEALTH_STORAGE_KEY ||
    event.key === FLIGHT_OPERATIONS_KEY ||
    event.key === COUNTDOWN_STORAGE_KEY ||
    event.key === BLISS_STORAGE_KEY
  ) {
    state = { ...defaults, ...readStorage(KEY, {}) };
    populateHealthFields(getSavedHealth());
    refreshSharedViews();
    renderCountdowns();
    updateDragonflyBlissStatus();
  }
});

// Morning Intelligence v2.1 — Phase 2 Intelligence Engine
function intelligenceSetText(id, value) {
  const element = document.getElementById(id);
  if (element) element.textContent = value;
}

function intelligenceEscape(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function intelligenceClean(value) {
  return String(value ?? "").trim();
}

function intelligenceDaysUntil(dateValue) {
  if (!dateValue) return null;

  const parts = String(dateValue).split("-").map(Number);
  if (
    parts.length !== 3 ||
    parts.some(part => !Number.isFinite(part))
  ) {
    return null;
  }

  const target = new Date(parts[0], parts[1] - 1, parts[2]);
  const now = new Date();
  const today = new Date(
    now.getFullYear(),
    now.getMonth(),
    now.getDate()
  );

  return Math.round((target - today) / 86400000);
}

function intelligenceGreeting(now = new Date()) {
  if (now.getHours() < 12) return "Good Morning";
  if (now.getHours() < 17) return "Good Afternoon";
  return "Good Evening";
}

function intelligenceModeLanguage(mode) {
  const modes = {
    home: {
      context: "Today is operating in Home Mode.",
      note: "Create one meaningful win inside Dragonfly Bliss."
    },
    flight: {
      context: "Today is operating in Flight Attendant Mode.",
      note: "Operational readiness comes before everything optional."
    },
    turbulence: {
      context: "Turbulence Mode is protecting today's energy.",
      note: "Steady progress—not perfection—is the assignment."
    }
  };

  return modes[mode] || modes.home;
}

function intelligenceReadSnapshot() {
  const countdowns = readStorage(COUNTDOWN_STORAGE_KEY, []);
  const bliss = readStorage(BLISS_STORAGE_KEY, {});

  return {
    state: {
      ...defaults,
      ...readStorage(KEY, {})
    },
    health: getHealthData(),
    flight: readStorage(FLIGHT_OPERATIONS_KEY, {}),
    countdowns: Array.isArray(countdowns) ? countdowns : [],
    bliss: bliss && typeof bliss === "object" ? bliss : {}
  };
}

function intelligenceAppointment(snapshot) {
  const purpose = intelligenceClean(snapshot.state.appointmentPurpose);
  const date = snapshot.state.followUpDate || "";
  const days = intelligenceDaysUntil(date);

  if (!purpose && days === null) return null;

  return {
    purpose: purpose || "Appointment follow-up",
    date,
    days
  };
}

function intelligenceActiveCountdowns(countdowns) {
  if (!Array.isArray(countdowns)) return [];

  return countdowns
    .map(item => ({
      ...item,
      days: intelligenceDaysUntil(item.date)
    }))
    .filter(item => item.days !== null && item.days >= 0)
    .sort((a, b) => a.days - b.days);
}

function intelligenceTopThree(snapshot) {
  const { state: stateData, health, bliss, flight } = snapshot;
  const items = [];

  const add = value => {
    const clean = intelligenceClean(value);
    if (clean && !items.includes(clean)) items.push(clean);
  };

  add(stateData.current);
  add(stateData.next);

  const incompleteTask = Array.isArray(stateData.tasks)
    ? stateData.tasks.find(task => !task.done && task.text)
    : null;
  if (incompleteTask) add(incompleteTask.text);

  if (stateData.mode === "flight") {
    if (
      !intelligenceClean(flight.opsFlightNumber) &&
      !intelligenceClean(flight.opsRoute)
    ) {
      add("Complete flight number and route");
    }
    if (!stateData.reportTime) add("Confirm report time");
    if (!stateData.leaveTime) add("Set leave-home time");
  }

  const appointment = intelligenceAppointment(snapshot);
  if (
    appointment &&
    appointment.days !== null &&
    appointment.days >= 0 &&
    appointment.days <= 7
  ) {
    add(`Prepare for ${appointment.purpose}`);
  }

  if (health.waterValue < 64) add("Bring water forward early");
  if (health.proteinValue < 85) {
    add("Anchor the next meal with protein");
  }
  if (!health.exerciseComplete) {
    add(
      stateData.mode === "turbulence"
        ? "Choose ten minutes of gentle movement"
        : "Place movement on today's flight path"
    );
  }

  if (stateData.mode === "home") {
    const blissAreas = [
      ["blissHomeDone", "Create one small home win"],
      ["blissGardenDone", "Touch the garden for ten minutes"],
      ["blissPhotographyDone", "Take today's intentional photo"],
      ["blissMealPrepDone", "Complete one meal-prep step"],
      ["blissLaundryDone", "Move one laundry load forward"],
      ["blissWorkoutDone", "Complete today's workout"]
    ];

    const firstIncomplete = blissAreas.find(
      ([id]) => !Boolean(bliss[id])
    );
    if (firstIncomplete) add(firstIncomplete[1]);
  }

  add(stateData.later);

  return items.slice(0, 3);
}

function intelligenceUpcoming(snapshot) {
  const { state: stateData, flight, countdowns } = snapshot;
  const items = [];
  const now = new Date();

  if (stateData.leaveTime) {
    const [hours, minutes] = stateData.leaveTime.split(":").map(Number);
    const target = new Date(now);
    target.setHours(hours, minutes, 0, 0);
    if (target < now) target.setDate(target.getDate() + 1);

    const remaining = Math.max(
      0,
      Math.floor((target - now) / 60000)
    );
    const hourPart = Math.floor(remaining / 60);
    const minutePart = remaining % 60;

    items.push({
      icon: "⏱",
      text: `Leave-home time is in ${hourPart}h ${minutePart}m.`
    });
  }

  const flightLine = [
    intelligenceClean(flight.opsFlightNumber),
    intelligenceClean(flight.opsRoute)
  ].filter(Boolean).join(" • ");

  if (flightLine) {
    items.push({
      icon: "✈️",
      text: flightLine
    });
  }

  if (intelligenceClean(flight.opsVanTime)) {
    items.push({
      icon: "🚐",
      text: `Van time: ${captainTime(flight.opsVanTime)}.`
    });
  }

  const activeCountdowns = intelligenceActiveCountdowns(countdowns);
  activeCountdowns.slice(0, 3).forEach(item => {
    const name = intelligenceClean(item.name || item.event) ||
      "Upcoming event";
    const timing = item.days === 0
      ? "today"
      : `in ${item.days} day${item.days === 1 ? "" : "s"}`;

    items.push({
      icon:
        item.category === "Travel" ? "🧳" :
        item.category === "Money" ? "💵" :
        item.category === "Work" ? "📌" :
        item.category === "Health" ? "🩺" : "📅",
      text: `${name} is ${timing}.`
    });
  });

  const appointment = intelligenceAppointment(snapshot);
  if (
    appointment &&
    appointment.days !== null &&
    appointment.days >= 0 &&
    appointment.days <= 7
  ) {
    const timing = appointment.days === 0
      ? "today"
      : `in ${appointment.days} day${appointment.days === 1 ? "" : "s"}`;

    items.push({
      icon: "🩺",
      text: `${appointment.purpose} is ${timing}.`
    });
  }

  return items.slice(0, 5);
}

function intelligenceHealthSentence(health) {
  const notes = [];

  if (health.waterValue >= 128) {
    notes.push("your water goal is complete");
  } else if (health.waterValue >= 64) {
    notes.push(`you are making steady progress with water at ${health.waterValue} ounces`);
  } else {
    notes.push(`your body would benefit from bringing water forward; you are at ${health.waterValue} ounces`);
  }

  if (health.proteinValue >= 170) {
    notes.push("your protein goal is complete");
  } else if (health.proteinValue >= 85) {
    notes.push(`protein is moving in the right direction at ${health.proteinValue} grams`);
  } else {
    notes.push(`protein needs a dependable anchor; you are at ${health.proteinValue} grams`);
  }

  notes.push(
    health.exerciseComplete
      ? "and your movement is already complete"
      : "and movement is still available to support the day"
  );

  return `${notes.join(", ")}.`;
}

function intelligenceBlissSentence(bliss) {
  const areas = [
    "blissHomeDone",
    "blissGardenDone",
    "blissPhotographyDone",
    "blissMealPrepDone",
    "blissLaundryDone",
    "blissWorkoutDone"
  ];

  const complete = areas.filter(id => Boolean(bliss[id])).length;

  if (complete === 6) {
    return "Dragonfly Bliss is fully tended today.";
  }

  if (complete > 0) {
    return `${complete} of 6 Dragonfly Bliss areas are complete, which is meaningful progress.`;
  }

  return "Dragonfly Bliss does not need a grand gesture today; one small home win is enough.";
}

function intelligenceNarrative(snapshot, topThree, upcoming) {
  const { state: stateData, health, bliss, flight } = snapshot;
  const mode = String(stateData.mode || "home").toLowerCase();
  const sentences = [];

  if (mode === "flight") {
    const flightLine = [
      intelligenceClean(flight.opsFlightNumber),
      intelligenceClean(flight.opsRoute)
    ].filter(Boolean).join(" • ");

    sentences.push(
      flightLine
        ? `You are in Flight Attendant Mode for ${flightLine}. Let the operational details lead, and allow everything optional to stay quiet.`
        : "You are in Flight Attendant Mode. The clearest next move is to complete the flight picture so the rest of the day can organize around it."
    );
  } else if (mode === "turbulence") {
    sentences.push(
      "You are in Turbulence Mode today. We are protecting your energy, reducing the noise, and keeping only what truly matters."
    );
  } else {
    sentences.push(
      "You are in Home Mode, with room to care for your body, prepare gently, and create one meaningful Dragonfly Bliss win."
    );
  }

  if (topThree.length) {
    sentences.push(
      `The first useful focus is ${topThree[0].replace(/[.]+$/, "")}.`
    );
  }

  sentences.push(intelligenceHealthSentence(health));

  const appointment = intelligenceAppointment(snapshot);
  if (
    appointment &&
    appointment.days !== null &&
    appointment.days >= 0 &&
    appointment.days <= 7
  ) {
    sentences.push(
      appointment.days === 0
        ? `${appointment.purpose} is today, so a calm review of your questions and notes will help you feel prepared.`
        : `${appointment.purpose} is coming in ${appointment.days} day${appointment.days === 1 ? "" : "s"}, which gives you time to prepare without rushing.`
    );
  } else if (upcoming.length) {
    sentences.push(
      `There ${upcoming.length === 1 ? "is" : "are"} ${upcoming.length} visible preparation item${upcoming.length === 1 ? "" : "s"}, but they do not all need your attention at once.`
    );
  }

  if (mode === "home") {
    sentences.push(intelligenceBlissSentence(bliss));
  }

  sentences.push(
    "We are not trying to conquer the whole day at once—just to choose the next wise move."
  );

  return sentences.join(" ");
}

function intelligenceObservation(snapshot, upcoming) {
  const { state: stateData, health } = snapshot;
  const mode = String(stateData.mode || "home").toLowerCase();

  if (mode === "turbulence") {
    return {
      observation:
        "Today does not require your full capacity to still be a good day.",
      next:
        "Choose one essential mission, hydrate, eat something supportive, and let the rest move without guilt."
    };
  }

  const appointment = intelligenceAppointment(snapshot);
  if (
    appointment &&
    appointment.days !== null &&
    appointment.days >= 0 &&
    appointment.days <= 2
  ) {
    return {
      observation:
        `${appointment.purpose} is close enough to deserve a little attention now.`,
      next:
        "Review your purpose, questions, and notes so future-you walks in feeling prepared."
    };
  }

  if (
    health.waterValue >= 128 &&
    health.proteinValue >= 170 &&
    health.exerciseComplete
  ) {
    return {
      observation:
        "Your primary health instruments are complete, and that deserves to be acknowledged.",
      next:
        "Protect your pace now. You do not need to add more simply because you can."
    };
  }

  if (health.waterValue < 64) {
    return {
      observation:
        "Your body is asking for water before it asks for more productivity.",
      next:
        "Finish one full bottle, then return to the day with a clearer system."
    };
  }

  if (health.proteinValue < 85) {
    return {
      observation:
        "Protein is the most supportive next anchor for your energy.",
      next:
        "Choose one dependable protein source and let that be enough for the next move."
    };
  }

  if (!health.exerciseComplete) {
    return {
      observation:
        "Movement is still open, but it does not need to be dramatic to count.",
      next:
        mode === "flight"
          ? "Choose a short session that respects the trip and your energy."
          : "Place a realistic movement block on the flight path and keep it kind."
    };
  }

  if (upcoming.length > 0) {
    return {
      observation:
        "Your preparation window is visible, which means you no longer have to carry it all in your head.",
      next:
        "Choose the first upcoming item and give only that one your attention."
    };
  }

  return {
    observation:
      "Your core systems are steady, and there is no emergency hiding in the day.",
    next:
      "Begin with the first item in your Top Three and let the rest wait its turn."
  };
}

function updateMorningIntelligence() {
  const panel = document.getElementById("morningIntelligenceTitle");
  if (!panel) return;

  try {
    const snapshot = intelligenceReadSnapshot();
    const stateData = snapshot.state;
    const now = new Date();
    const mode = String(stateData.mode || "home").toLowerCase();
    const language = intelligenceModeLanguage(mode);

    const mission =
      intelligenceClean(stateData.mission) ||
      "Name the one outcome that would make today feel intentionally flown.";

    const topThree = intelligenceTopThree(snapshot);
    const upcoming = intelligenceUpcoming(snapshot);
    const observation = intelligenceObservation(snapshot, upcoming);

    intelligenceSetText(
      "morningIntelligenceTitle",
      `${intelligenceGreeting(now)}, Captain Ren`
    );
    intelligenceSetText(
      "morningIntelligenceContext",
      language.context
    );
    intelligenceSetText("intelligenceMission", mission);
    intelligenceSetText("intelligenceModeNote", language.note);
    intelligenceSetText(
      "intelligenceNarrative",
      intelligenceNarrative(snapshot, topThree, upcoming)
    );

    const topThreeElement =
      document.getElementById("intelligenceTopThree");
    if (topThreeElement) {
      topThreeElement.innerHTML = topThree.length
        ? topThree
            .map(item => `<li>${intelligenceEscape(item)}</li>`)
            .join("")
        : "<li>Choose today's first priority.</li>";
    }

    const upcomingElement =
      document.getElementById("intelligenceUpcoming");
    if (upcomingElement) {
      upcomingElement.innerHTML = upcoming.length
        ? upcoming
            .map(item => `
              <div class="intelligence-upcoming-item">
                <span class="intelligence-upcoming-icon">${item.icon}</span>
                <span>${intelligenceEscape(item.text)}</span>
              </div>
            `)
            .join("")
        : "<p>No urgent preparation is showing.</p>";
    }

    intelligenceSetText(
      "intelligenceObservation",
      observation.observation
    );
    intelligenceSetText(
      "intelligenceNextMove",
      observation.next
    );

    const status =
      document.getElementById("morningIntelligenceStatus");
    if (status) {
      status.textContent = upcoming.length
        ? `${upcoming.length} UPCOMING`
        : "SYSTEMS STEADY";
    }
  } catch (error) {
    console.error("Morning Intelligence could not refresh.", error);
    intelligenceSetText(
      "morningIntelligenceContext",
      "The briefing needs one quick refresh."
    );
    intelligenceSetText(
      "intelligenceNarrative",
      "Your saved Command Center data remains intact. Refresh the page once; if this message remains, open the browser console for the exact error."
    );
  }
}

function initializeMorningIntelligence() {
  updateMorningIntelligence();

  document.addEventListener("input", () => {
    window.setTimeout(updateMorningIntelligence, 0);
  });

  document.addEventListener("change", () => {
    window.setTimeout(updateMorningIntelligence, 0);
  });

  window.addEventListener("storage", updateMorningIntelligence);
  window.setInterval(updateMorningIntelligence, 60000);
}

// The script is loaded at the bottom of index.html, but this handles both states.
if (document.readyState === "loading") {
  document.addEventListener(
    "DOMContentLoaded",
    initializeMorningIntelligence,
    { once: true }
  );
} else {
  initializeMorningIntelligence();
}
