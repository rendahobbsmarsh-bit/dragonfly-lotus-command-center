# DragonFly Lotus V4.0 — Living Intelligence + Quick Journal

V4.0 begins the Living Intelligence chapter while preserving the stable
V3.2 health and mission foundation.

## New: Captain's Log

The Quick Journal provides a sixty-second daily reflection:

- choose a mood
- record one win
- release one thing
- keep one meaningful moment
- add an optional quick note
- edit or delete recent entries
- export the complete journal as a text file

Only one entry is stored per date. Saving again updates that day's entry.

## Automatic Daily Review

The journal automatically reads the unified Command Center data and displays:

- today's mission
- water
- protein
- movement
- a Sage reflection based on the day and journal mood

## Living Intelligence connection

Sage's Observations can now notice when:

- a win has already been recorded
- the journal mood is Tired or Turbulent
- the day needs gentler expectations

## Install

Upload this ZIP into the Codespaces repository root and run:

```bash
unzip -o DragonFly_Lotus_v4_0_Living_Intelligence_Quick_Journal.zip
git add .
git commit -m "DragonFly Lotus V4.0 - Living Intelligence and Quick Journal"
git push
```

GitHub Pages deploys automatically.

After deployment, fully close and reopen the installed DragonFly Lotus app.
The service-worker cache has been advanced to V4.0.

## Data note

Journal entries are stored locally in the browser with the rest of the current
Command Center data. They do not mirror between Mac, phone, and iPad until cloud
sync is added.
