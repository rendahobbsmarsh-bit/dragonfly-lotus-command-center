# DragonFly Lotus V3 — Next Mission + Mission Calendar

Adds future-dated missions, pre-dawn wake/leave/report times, hotel van time,
multi-leg routes, and monthly schedule paste import.

Install:
unzip -o DragonFly_Lotus_v3_Next_Mission_Calendar.zip

Refresh with Command + Shift + R.

Data still remains local to each browser/device until cloud sync is added.
