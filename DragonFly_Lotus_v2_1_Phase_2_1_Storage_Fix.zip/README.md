# DragonFly Lotus v2.1 — Phase 2.1 Storage Fix

This corrective release fixes the Phase Two error:

`ReferenceError: BLISS_STORAGE_KEY is not defined`

## What changed

- All localStorage keys now live in one central `STORAGE_KEYS` configuration.
- `BLISS_STORAGE_KEY` is defined and shared by Dragonfly Bliss and Morning Intelligence.
- Dragonfly Bliss uses the shared safe storage reader.
- Morning Intelligence safely handles malformed or missing Bliss/countdown data.
- Existing browser data and storage-key names are unchanged.

## Install in Codespaces

Upload this ZIP into the repository root, then run:

```bash
unzip DragonFly_Lotus_v2_1_Phase_2_1_Storage_Fix.zip
```

When prompted to replace files, type `A` and press Return.

Refresh the live Command Center with:

`Command + Shift + R`

## Verify before committing

1. Morning Intelligence should no longer show “The briefing needs one quick refresh.”
2. The Console should no longer show `BLISS_STORAGE_KEY is not defined`.
3. Dragonfly Bliss should load normally.
4. Change Water, Protein, Mission, Current/Next, or an appointment and confirm the briefing updates.

## Commit after verification

```bash
git add app.js README.md
git commit -m "Fix Morning Intelligence and Bliss storage keys"
git push
```
