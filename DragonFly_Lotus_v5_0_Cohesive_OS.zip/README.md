# DragonFly Lotus V5.0 — Cohesive Personal OS

V5 turns the existing modules into one coherent operating experience.

## V5 core

- Six stable workspaces: Today, Flight Deck, Health, Money, Bliss, and Captain’s Log
- A new **System Snapshot** on Today
- Quick-add water and protein controls
- One glance at next mission, health, current focus, and recent memory
- A **Data Vault** for complete JSON backup and manual transfer between devices
- Online/offline status and offline-ready PWA shell
- Existing V4.1 workspace design, V4 journal, V3.2 health core, and mission calendar retained

## Important installation step

Uploading this ZIP does not update the live website by itself. It must be extracted
so that `index.html`, `styles.css`, and `app.js` replace the current live files.

In the Codespaces terminal run:

```bash
unzip -o DragonFly_Lotus_v5_0_Cohesive_OS.zip
git add .
git commit -m "DragonFly Lotus V5.0 - Cohesive personal OS"
git push
```

After the GitHub Pages workflow turns green:

1. Open the permanent GitHub Pages site in Chrome.
2. Press Command + Shift + R once.
3. Completely quit the installed DragonFly Lotus app.
4. Reopen the app.

You will know V5 is active when you see:

- a `V5.0` chip in the header
- the six workspace navigation buttons
- `SYSTEM SNAPSHOT` under the mode selector
- `DATA VAULT` on the Today workspace

## Data note

Data is still stored locally on each device. The new Data Vault provides a safe
manual backup and transfer path until cloud synchronization is built.
