# DragonFly Lotus v2.7 — Sage Observations + Flight Deck

This release adds two focused layers.

## v2.6 — Sage's Observations

The Command Center now creates 3–5 live observations based on:

- water
- protein
- exercise
- upcoming items
- Dragonfly Bliss
- Home / Flight / Turbulence mode
- recent learning history

The observations are designed to sound like Sage: calm, practical, motivational,
and focused on what the day means—not just what the numbers are.

## v2.7 — Sage's Flight Deck

The route field accepts a multi-leg pairing such as:

`DAL - AUS - TPA - SEA`

The system interprets:

- the first two cities as the next leg
- the final city as the overnight
- the full route as the pairing sequence

Flighty remains the source for live gate, delay, and operational changes.

DragonFly Lotus focuses on preparation, pacing, hydration, fuel, and the next leg.

## Install

Upload the ZIP into the Codespaces project root and run:

```bash
unzip -o DragonFly_Lotus_v2_7_Flight_Deck_Complete.zip
```

Refresh the live Command Center with:

`Command + Shift + R`

## Verify

1. “Sage's Observations” appears.
2. “Sage's Flight Deck” appears.
3. Enter `DAL - AUS - TPA - SEA` in Route.
4. Confirm `DAL → AUS` appears as Next Leg.
5. Confirm `SEA` appears as the overnight.
6. Switch Home / Flight Attendant / Turbulence modes and confirm the briefing changes.

## Commit

```bash
git add index.html styles.css app.js README.md
git commit -m "DragonFly Lotus v2.7 - Sage observations and flight deck"
git push
```
