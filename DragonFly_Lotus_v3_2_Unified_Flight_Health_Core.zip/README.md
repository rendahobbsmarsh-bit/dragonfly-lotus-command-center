# DragonFly Lotus V3.2 — Unified Flight & Health Core

This is a stability and simplification release based on Captain Ren's five-day flight test.

## What changed

### One health record
Water, protein, exercise, weight, sleep, and notes now save through one canonical health record.
A change immediately refreshes:

- Health Dashboard
- Captain's Briefing
- Captain's Recommendations
- Morning Intelligence
- Sage's Observations
- learning snapshots

The duplicate Original Instruments panel was removed. Quick-add buttons now live directly inside the Unified Health Core.

### One pairing entry
Mission Calendar is now the single place to enter flight and pairing data.
The duplicate Flight Operations form was removed.

A flight mission automatically supplies:

- pairing / flight number
- full route
- first leg
- overnight city
- leave-home time
- report time
- hotel van time
- notes

Next Mission, Flight Deck, Upcoming, and Morning Intelligence all read from that same mission record.

### Retention reliability
The app refreshes its canonical records when reopened or returned to the foreground.
The PWA cache was advanced to V3.2 so the new files replace older cached code.

## Install

```bash
unzip -o DragonFly_Lotus_v3_2_Unified_Flight_Health_Core.zip
git add .
git commit -m "DragonFly Lotus V3.2 - Unified flight and health core"
git push
```

GitHub Pages will deploy automatically. After deployment, fully close and reopen the installed DragonFly Lotus app once so the V3.2 service worker takes control.

## Important

Data remains local to each browser/device until cloud sync is built.
