# DragonFly Lotus v2.5 — Intelligence Complete

This release completes the planned v2.2 through v2.5 intelligence work.

## v2.2 — Sage Voice
Warm, calm, practical language focused on one wise next move.

## v2.3 — Time-Aware Intelligence
Different perspective for preflight, morning, afternoon, evening and wind-down.

## v2.4 — Flight-Aware Intelligence
Flight Attendant Mode reads flight number, route, report/leave time and van time.
Home and Turbulence modes receive different guidance.

## v2.5 — Learning Engine
The Command Center records one daily snapshot in localStorage and studies up to
30 recent days. It can notice:

- water running behind your usual rhythm
- protein running below your recent average
- exercise consistency
- Home Mode Dragonfly Bliss rhythm
- Flight Attendant preparation patterns

Learning starts showing meaningful observations after three recorded days.

## Install in Codespaces

Upload this ZIP into the project root and run:

```bash
unzip -o DragonFly_Lotus_v2_5_Intelligence_Complete.zip
```

Refresh the live Command Center with:

`Command + Shift + R`

## Verify

1. Briefing sounds warm and motivational.
2. Time-of-day language matches the current time.
3. Flight Attendant Mode changes the briefing.
4. “Patterns Sage Is Noticing” appears.
5. Console shows no Morning Intelligence errors.

## Commit

```bash
git add index.html styles.css app.js README.md
git commit -m "DragonFly Lotus v2.5 - Intelligence complete"
git push
```
